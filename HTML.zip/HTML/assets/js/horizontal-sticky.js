$(".hor-menu").sticky({
	topSpacing:-1
});